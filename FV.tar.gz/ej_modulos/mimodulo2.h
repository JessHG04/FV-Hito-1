#pragma once

class MiModulo2 {

public:
  MiModulo2();
};