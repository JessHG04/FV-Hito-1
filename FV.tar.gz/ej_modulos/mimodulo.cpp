#include "mimodulo.h"

#include <iostream>

MiModulo::MiModulo() {
    std::cout << "Creando mi modulo..."; 
}