#pragma once

class MiModulo{
    
    public:
     MiModulo();

};