#include "mimodulo2.h"

#include <iostream>

MiModulo2::MiModulo2() {
  std::cout << "Creando mi modulo2...";
}